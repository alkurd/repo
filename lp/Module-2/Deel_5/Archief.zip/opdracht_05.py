from fruitmand import fruitmand
for i in fruitmand:
    print(f"{i['name']}")
print("--------------------------------")
for i in reversed(fruitmand):
    print(f"{i['name']}")