from fruitmand import fruitmand
print(len(fruitmand))